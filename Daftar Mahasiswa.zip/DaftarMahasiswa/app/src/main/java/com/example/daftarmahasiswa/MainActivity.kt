package com.example.daftar_mahasiswa

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.daftar_mahasiswa.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Data mahasiswa, pastikan urutannya sesuai dengan yang Anda inginkan
        val mahasiswaList = listOf(
            Pair("Rohim ", " SSI202203179"),
            Pair("Kotaro minami ", " SSI202203180"),
            Pair("Sembara ", " SSI202203181"),
            Pair("Angling Darmo ", " SSI202203182"),
            Pair("Lupus ", " SSI202203183"),
            Pair("Trimanto", "SSI202203184"),
            Pair("Darno ", " SSI202203185"),
            Pair("Roydah ", " SSI202203186"),
            Pair("Ronaldo ", " SSI202203187"),
            Pair("Messi ", " SSI202203188"),
            Pair("Warsin Silitonga ", " SSI202203189")
        )

        // Mengatur teks dari TextViews
        binding.student1.text = "Nama: ${mahasiswaList[0].first}                     NIM: ${mahasiswaList[0].second}"
        binding.student2.text = "Nama: ${mahasiswaList[1].first}                     NIM: ${mahasiswaList[1].second}"
        binding.student3.text = "Nama: ${mahasiswaList[2].first}                     NIM: ${mahasiswaList[2].second}"
        binding.student4.text = "Nama: ${mahasiswaList[3].first}                     NIM: ${mahasiswaList[3].second}"
        binding.student5.text = "Nama: ${mahasiswaList[4].first}                     NIM: ${mahasiswaList[4].second}"
        binding.student6.text = "Nama: ${mahasiswaList[5].first}                     NIM: ${mahasiswaList[5].second}"
        binding.student7.text = "Nama: ${mahasiswaList[6].first}                     NIM: ${mahasiswaList[6].second}"
        binding.student8.text = "Nama: ${mahasiswaList[7].first}                     NIM: ${mahasiswaList[7].second}"
        binding.student9.text = "Nama: ${mahasiswaList[8].first}                     NIM: ${mahasiswaList[8].second}"
        binding.student10.text = "Nama: ${mahasiswaList[9].first}                     NIM: ${mahasiswaList[9].second}"
        binding.student11.text = "Nama: ${mahasiswaList[10].first}                     NIM: ${mahasiswaList[10].second}"
    }
}

